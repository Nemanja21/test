from django.shortcuts import render
from rest_framework import viewsets, mixins
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import get_object_or_404

from authentication.models import CustomUser, LoginLog
from api.serializers import *

# Create your views here.

class UserViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    permission_classes = (IsAuthenticated,)

    queryset = CustomUser.objects.all().order_by('-date_joined')
    serializer_class = UserSerializer

class LoginViewSet(mixins.RetrieveModelMixin,
                mixins.ListModelMixin,
                viewsets.GenericViewSet):

    permission_classes = (IsAuthenticated,)

    queryset = LoginLog.objects.all().order_by('-user_id')
    serializer_class = LoginSerializer

    def list(self, request):
        """override"""
        page = self.paginate_queryset(self.queryset)
        serializer = LoginAllSerializer(page, many=True)
        return self.get_paginated_response(serializer.data)

    def retrieve(self, request, pk=None): 
        """override"""
        module = LoginLog.objects.filter(user_id=pk)
        serializer = LoginSerializer(module, many=True)
        return Response(serializer.data)