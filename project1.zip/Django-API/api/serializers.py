from rest_framework import serializers

from authentication.models import CustomUser, LoginLog

class UserSerializer(serializers.ModelSerializer):

    class Meta:
        model = CustomUser
        fields = ('username', 'email', 'date_joined', 'last_login', 'is_eliminated', 'date_eliminated')



class LoginSerializer(serializers.ModelSerializer):

    # customuser = UserSerializer

    class Meta:
        model = LoginLog
        fields = ('host', 'login_time')


class LoginAllSerializer(serializers.ModelSerializer):

    # customuser = UserSerializer

    class Meta:
        model = LoginLog
        fields = ('user_id', 'host', 'login_time')