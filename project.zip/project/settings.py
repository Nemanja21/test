import os

from engine.folder_file_manager import make_directory_if_not_exists

CUR_DIR = os.path.dirname(os.path.abspath(__file__))
PLAYER_FRAME_DIR = make_directory_if_not_exists(os.path.join(CUR_DIR, 'player_frame'))
MODEL_DIR = os.path.join(CUR_DIR, 'utils', 'model')
UPLOAD_DIR = make_directory_if_not_exists(os.path.join(CUR_DIR, 'engine', 'uploads'))

PLAYER_MODEL_PATH = os.path.join(MODEL_DIR, 'player_detector.pb')
GRADE_MODEL_PATH = os.path.join(MODEL_DIR, 'grade_detector.pb')
CREDENTIAL_PATH = os.path.join(CUR_DIR, 'utils', 'credential', 'vision_key.txt')

INCEPTION_URL = 'http://download.tensorflow.org/models/image/imagenet/inception-2015-12-05.tgz'

CONFIDENCE = 0.8
FEATURE_MATCHING_THERSH = 0.8
KEY_POINT_MATCHING_THRESH = 1
Y_BIND_THREAD = 10
ROTATION_Y_THREAD = 50
LOCAL = True

SERVER_HOST = "0.0.0.0"
SERVER_PORT = 5000

