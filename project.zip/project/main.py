from flask import Flask, render_template, request, flash, redirect
from werkzeug.utils import secure_filename

import os
import time

from engine import clean, models, folder_file_manager, predict
from settings import UPLOAD_DIR, SERVER_HOST, SERVER_PORT, LOCAL

app = Flask(__name__)
app.config['SECRET_KEY'] = 'the random string'
app.config['UPLOAD_FOLDER'] = UPLOAD_DIR

@app.route('/')
def index():
    return render_template("index.html", messages=None)

@app.route('/upload_file', methods=['POST'])
def upload():
    try:
        print(request.files)
        file = request.files['audio_data']
        file_name = secure_filename(file.filename) + '.wav'
        file_path = os.path.join(UPLOAD_DIR, file_name)
        file.save(file_path)

        label, acc = predict.make_prediction(file_path)

        result = str(round(acc[0] * 100))     
        # result_info["filename"] = file_name
        return result
    except Exception as e:
        folder_file_manager.log_print(info_str=e)
        return render_template('results.html', static_path='../static/', messages=e, filename=None, data=None)

if __name__ == '__main__':
    if LOCAL:
        app.run(debug=True, host=SERVER_HOST, port=SERVER_PORT)
    else:
        app.run(debug=False, host=SERVER_HOST, port=SERVER_PORT)