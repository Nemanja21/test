from flask import Flask, render_template     
from apscheduler.schedulers.background import BackgroundScheduler

import time

app = Flask(__name__)

sched = BackgroundScheduler(daemon=True)
sched.start()

##############################################################################    
###################### Set address of RELAYplate below: ######################
##############################################################################
 
##############################################################################
###### Customize the names of your relays by changing the labels below: ######
labels=['Relay 1','Relay 2','Relay 3','Relay 4','Relay 5','Relay 6','Relay 7',
        'Relay 8','Relay 9','Relay 10','Relay 11','Relay 12','Relay 13','Relay 14']
##############################################################################

##############################################################################
######## Customize the title of your page by changing the text below: ########
title='Remote RELAYplate Controller'
############################################################################## 

status = ['OFF', 'OFF', 'OFF', 'OFF', 'OFF', 'OFF', 'OFF',
          'OFF', 'OFF', 'OFF', 'OFF', 'OFF', 'OFF', 'OFF']

counters = [0,0,0,0,0,0,0,0,0,0,0,0,0,0]

@app.route("/")                                                                 
@app.route("/<state>")                                                          
def update_relay(state=None): 
    if state != None:    
        rly=int(state[0:2])   #parse relay number              
        action=state[3]     #parse action: 'n' for on and 'f' for off
        if action=='n':
            if counters[rly-1] != 0:
                sched.remove_job('j'+str(rly))
                status[rly-1] = 'OFF'
                counters[rly-1] = 0
            status[rly-1] = 'ON'
            #app.apscheduler.add_job(func=scheduled_task, trigger='date', args=[rly, state[4:6]], id='j'+str(rly))
            sched.add_job(lambda: scheduled_task(rly, state[4:6]),'interval',seconds=int(state[4:6]), id='j'+str(rly))
            counters[rly-1] = int(state[6:])
        if action=='f':
            if counters[rly-1] != 0:
                sched.remove_job('j'+str(rly))
            status[rly-1] = 'OFF'
            counters[rly-1] = 0
            
    template_data = {'status' : status,
                    'labels' : labels,
                    'title' : title,
                    'counters' : counters,
                    }                                                                          
    return render_template('WebPage.html', **template_data)

def scheduled_task(task_id, times):
    status[task_id-1] = 'OFF'
    counters[task_id-1] = 0
    print(str(task_id) + ' is ' + status[task_id-1])
    sched.remove_job('j'+str(task_id))

if __name__== '__main__':                                                      
    app.run(host='0.0.0.0',port=8002)