from django.urls import path
from core.views import home, contacts

app_name = "core"

urlpatterns = [
    path('', home, name="home"),
    path('contacts', contacts, name="contact"),
]